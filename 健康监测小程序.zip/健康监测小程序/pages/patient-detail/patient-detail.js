// pages/patient-detail/patient-detail.js
var app = getApp();

Page({
  data: {
    isEdit: false,
    patientId: '',
    canManage: true,
    canSetRange: true,
    form: {
      name: '',
      age: '',
      gender: 1,
      bedNo: '',
      department: '',
      diagnosis: '',
      phone: '',
      notes: ''
    },
    // 指标范围设置（仅编辑模式）
    showRangeSettings: false,
    rangeItems: []
  },

  onLoad: function(options) {
    this.setData({
      canManage: app.hasPermission('canManage'),
      canSetRange: app.hasPermission('canSetRange')
    });

    // 非护士不能编辑患者信息
    if (!app.hasPermission('canManage') && options.id) {
      this.setData({ isEdit: true, patientId: options.id });
      this.loadPatient(options.id);
      return;
    }

    var indicators = app.globalData.indicators;
    var keys = ['waterIntake', 'urineOutput', 'weight', 'bloodPressureSystolic', 'bloodPressureDiastolic', 'heartRate', 'temperature'];
    var rangeItems = [];
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      var ind = indicators[k];
      rangeItems.push({
        key: k,
        name: ind.name,
        icon: ind.icon,
        unit: ind.unit,
        color: ind.color,
        defaultMin: ind.normalRange.min,
        defaultMax: ind.normalRange.max,
        customMin: '',
        customMax: ''
      });
    }
    this.setData({ rangeItems: rangeItems });

    if (options.id) {
      this.setData({ isEdit: true, patientId: options.id });
      this.loadPatient(options.id);
    }
  },

  // 加载患者信息
  loadPatient: function(id) {
    var patients = app.getPatients();
    var patient = null;
    for (var i = 0; i < patients.length; i++) {
      if (patients[i].id === id) { patient = patients[i]; break; }
    }
    if (patient) {
      this.setData({
        form: {
          name: patient.name || '',
          age: String(patient.age || ''),
          gender: patient.gender || 1,
          bedNo: patient.bedNo || '',
          department: patient.department || '',
          diagnosis: patient.diagnosis || '',
          phone: patient.phone || '',
          notes: patient.notes || ''
        }
      });

      // 加载自定义范围
      if (patient.customRanges) {
        var rangeItems = this.data.rangeItems;
        for (var j = 0; j < rangeItems.length; j++) {
          var rk = rangeItems[j].key;
          if (patient.customRanges[rk]) {
            rangeItems[j].customMin = String(patient.customRanges[rk].min);
            rangeItems[j].customMax = String(patient.customRanges[rk].max);
          }
        }
        this.setData({ rangeItems: rangeItems });
      }
    }
  },

  // 表单输入
  onInput: function(e) {
    var field = e.currentTarget.dataset.field;
    var data = {};
    data['form.' + field] = e.detail.value;
    this.setData(data);
  },

  // 性别切换
  onGenderChange: function(e) {
    this.setData({ 'form.gender': parseInt(e.detail.value) });
  },

  // 展开/收起范围设置
  toggleRangeSettings: function() {
    this.setData({ showRangeSettings: !this.data.showRangeSettings });
  },

  // 范围输入
  onRangeInput: function(e) {
    var index = e.currentTarget.dataset.index;
    var field = e.currentTarget.dataset.field;
    var rangeItems = this.data.rangeItems;
    rangeItems[index][field] = e.detail.value;
    this.setData({ rangeItems: rangeItems });
  },

  // 重置某个指标范围为默认
  resetRange: function(e) {
    var index = e.currentTarget.dataset.index;
    var rangeItems = this.data.rangeItems;
    rangeItems[index].customMin = '';
    rangeItems[index].customMax = '';
    this.setData({ rangeItems: rangeItems });
    wx.showToast({ title: '已重置为默认值', icon: 'success' });
  },

  // 表单验证
  validateForm: function() {
    var name = this.data.form.name;
    var age = this.data.form.age;
    if (!name.trim()) {
      wx.showToast({ title: '请输入患者姓名', icon: 'none' });
      return false;
    }
    if (!age || parseInt(age) <= 0 || parseInt(age) > 150) {
      wx.showToast({ title: '请输入有效年龄', icon: 'none' });
      return false;
    }
    return true;
  },

  // 收集自定义范围数据
  collectCustomRanges: function() {
    var rangeItems = this.data.rangeItems;
    var customRanges = {};
    for (var i = 0; i < rangeItems.length; i++) {
      var item = rangeItems[i];
      if (item.customMin !== '' && item.customMax !== '') {
        var minVal = parseFloat(item.customMin);
        var maxVal = parseFloat(item.customMax);
        if (!isNaN(minVal) && !isNaN(maxVal) && minVal < maxVal) {
          customRanges[item.key] = { min: minVal, max: maxVal };
        }
      }
    }
    return customRanges;
  },

  // 保存
  savePatient: function() {
    if (!this.validateForm()) return;

    var that = this;
    var form = this.data.form;
    var isEdit = this.data.isEdit;
    var patientId = this.data.patientId;
    var customRanges = this.collectCustomRanges();

    if (isEdit) {
      // 更新
      var patients = app.getPatients();
      var index = -1;
      for (var i = 0; i < patients.length; i++) {
        if (patients[i].id === patientId) { index = i; break; }
      }
      if (index !== -1) {
        patients[index] = {
          id: patientId,
          createdAt: patients[index].createdAt,
          name: form.name.trim(),
          age: parseInt(form.age),
          gender: form.gender,
          bedNo: form.bedNo.trim(),
          department: form.department.trim(),
          diagnosis: form.diagnosis.trim(),
          phone: form.phone.trim(),
          notes: form.notes.trim(),
          customRanges: customRanges
        };
        wx.setStorageSync('patients', patients);
        wx.showToast({ title: '保存成功', icon: 'success' });
        setTimeout(function() { wx.navigateBack(); }, 500);
      }
    } else {
      // 新增
      var id = app.addPatient({
        name: form.name.trim(),
        age: parseInt(form.age),
        gender: form.gender,
        bedNo: form.bedNo.trim(),
        department: form.department.trim(),
        diagnosis: form.diagnosis.trim(),
        phone: form.phone.trim(),
        notes: form.notes.trim(),
        customRanges: customRanges
      });
      app.setCurrentPatient(id);
      wx.showToast({ title: '添加成功', icon: 'success' });
      setTimeout(function() { wx.navigateBack(); }, 500);
    }
  }
});
