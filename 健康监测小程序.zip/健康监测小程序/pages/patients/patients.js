// pages/patients/patients.js
var app = getApp();

Page({
  data: {
    currentUser: null,
    patients: [],
    displayPatients: [],
    currentPatientId: '',
    maleCount: 0,
    femaleCount: 0,
    movedCount: 0,
    pendingCount: 0,
    searchKey: '',
    todayStr: '',
    greeting: '',
    canRecord: true,
    activeFilter: 'all',
    currentRoleName: '',
    // 长按菜单
    showMenu: false,
    menuPatientId: '',
    menuPatientName: '',
    // 出院/转科弹窗
    showMoveModal: false,
    moveModalPatientId: '',
    moveModalPatientName: '',
    moveReason: '',
    moveNote: '',
    // 出院列表弹窗
    showMovedList: false,
    movedPatientsFull: []
  },

  onShow: function() {
    if (!app.getCurrentRole()) {
      wx.reLaunch({ url: '/pages/login/login' });
      return;
    }
    var user = app.getCurrentUser();
    var role = app.getCurrentRole();
    var roleConfig = app.getRoleConfig(role);
    var roleName = roleConfig ? roleConfig.name : role;
    this.setData({
      currentUser: user,
      todayStr: app.getTodayStr(),
      greeting: this.getGreeting(),
      canRecord: app.hasPermission('canRecord'),
      pendingCount: app.getPendingCount(),
      currentRoleName: roleName
    });
    this.loadPatients();
    this.loadMovedPatients();
  },

  getGreeting: function() {
    var h = new Date().getHours();
    if (h < 6) return '夜深了';
    if (h < 9) return '早上好';
    if (h < 12) return '上午好';
    if (h < 14) return '中午好';
    if (h < 18) return '下午好';
    return '晚上好';
  },

  loadPatients: function() {
    var patients = app.getVisiblePatients();
    var currentId = wx.getStorageSync('currentPatientId') || '';
    var maleCount = 0, femaleCount = 0;
    for (var i = 0; i < patients.length; i++) {
      if (patients[i].gender === 1) maleCount++;
      else femaleCount++;
    }
    var filter = this.data.activeFilter;
    var displayPatients = patients;
    if (filter === 'male') {
      displayPatients = patients.filter(function(p) { return p.gender === 1; });
    } else if (filter === 'female') {
      displayPatients = patients.filter(function(p) { return p.gender !== 1; });
    }
    this.setData({
      patients: patients,
      displayPatients: displayPatients,
      currentPatientId: currentId,
      maleCount: maleCount,
      femaleCount: femaleCount,
      canManage: app.hasPermission('canManage')
    });
  },

  loadMovedPatients: function() {
    var all = app.getMovedPatients();
    this.setData({ movedCount: all.length });
  },

  // 搜索
  onSearch: function(e) {
    var key = (e.detail.value || '').trim().toLowerCase();
    this.doSearch(key);
  },

  // 按性别过滤
  filterPatients: function(e) {
    var filter = e.currentTarget.dataset.filter;
    this.setData({ activeFilter: filter, searchKey: '' });
    this.loadPatients();
  },

  clearSearch: function() {
    this.setData({ searchKey: '', displayPatients: this.data.patients });
  },

  doSearch: function(key) {
    this.setData({ searchKey: key });
    if (!key) {
      this.setData({ displayPatients: this.data.patients });
      return;
    }
    var filtered = this.data.patients.filter(function(p) {
      return (p.name && p.name.toLowerCase().indexOf(key) !== -1) ||
             (p.bedNo && p.bedNo.toLowerCase().indexOf(key) !== -1) ||
             (p.diagnosis && p.diagnosis.toLowerCase().indexOf(key) !== -1);
    });
    this.setData({ displayPatients: filtered });
  },

  // 点击选择患者 -> 进入首页查看详情
  selectPatient: function(e) {
    var id = e.currentTarget.dataset.id;
    app.setCurrentPatient(id);
    this.setData({ currentPatientId: id });
    wx.switchTab({ url: '/pages/index/index' });
  },

  // 跳转审批页面
  goToApply: function() {
    wx.navigateTo({ url: '/pages/apply/apply' });
  },

  // 长按 -> 弹出操作菜单
  showPatientMenu: function(e) {
    var id = e.currentTarget.dataset.id;
    var name = e.currentTarget.dataset.name;
    this.setData({ showMenu: true, menuPatientId: id, menuPatientName: name });
  },

  hideMenu: function() {
    this.setData({ showMenu: false });
  },

  viewPatientDetail: function() {
    var id = this.data.menuPatientId;
    this.setData({ showMenu: false });
    app.setCurrentPatient(id);
    wx.switchTab({ url: '/pages/index/index' });
  },

  viewPatientRecords: function() {
    var id = this.data.menuPatientId;
    this.setData({ showMenu: false });
    app.setCurrentPatient(id);
    wx.switchTab({ url: '/pages/index/index' });
  },

  editPatientFromMenu: function() {
    var id = this.data.menuPatientId;
    this.setData({ showMenu: false });
    wx.navigateTo({ url: '/pages/patient-detail/patient-detail?id=' + id });
  },

  moveOutFromMenu: function() {
    var id = this.data.menuPatientId;
    var name = this.data.menuPatientName;
    this.setData({
      showMenu: false,
      showMoveModal: true,
      moveModalPatientId: id,
      moveModalPatientName: name,
      moveReason: '',
      moveNote: ''
    });
  },

  // 添加患者
  addPatient: function() {
    wx.navigateTo({ url: '/pages/patient-detail/patient-detail' });
  },

  // 跳转人员管理
  goToNurseManage: function() {
    wx.navigateTo({ url: '/pages/nurse-manage/nurse-manage' });
  },

  // 跳转快速记录
  goToRecord: function() {
    wx.switchTab({ url: '/pages/record/record' });
  },

  goToHome: function() {
    wx.switchTab({ url: '/pages/index/index' });
  },

  // 出院/转科弹窗
  selectReason: function(e) {
    this.setData({ moveReason: e.currentTarget.dataset.reason });
  },

  onNoteInput: function(e) {
    this.setData({ moveNote: e.detail.value });
  },

  closeMoveModal: function() {
    this.setData({ showMoveModal: false });
  },

  confirmMoveOut: function() {
    if (!this.data.moveReason) return;
    var that = this;
    var id = this.data.moveModalPatientId;
    var name = this.data.moveModalPatientName;
    var reason = this.data.moveReason;
    var note = this.data.moveNote;
    wx.showModal({
      title: reason === 'discharge' ? '确认出院' : '确认转科',
      content: '确定将患者"' + name + '"' + (reason === 'discharge' ? '办理出院' : '办理转科') + '吗？',
      success: function(res) {
        if (res.confirm) {
          app.moveOutPatient(id, reason, note);
          that.setData({ showMoveModal: false });
          that.loadPatients();
          that.loadMovedPatients();
          wx.showToast({ title: reason === 'discharge' ? '已出院' : '已转科', icon: 'success' });
        }
      }
    });
  },

  // 出院/转科列表
  viewMovedPatients: function() {
    var all = app.getMovedPatients();
    all = all.map(function(p) {
      p.movedOutTime = p.movedOutAt ? formatDate(p.movedOutAt) : '';
      return p;
    });
    this.setData({ showMovedList: true, movedPatientsFull: all });
  },

  closeMovedList: function() {
    this.setData({ showMovedList: false });
  },

  restorePatient: function(e) {
    var id = e.currentTarget.dataset.id;
    var that = this;
    wx.showModal({
      title: '恢复在院',
      content: '确定将该患者恢复到在院列表吗？',
      success: function(res) {
        if (res.confirm) {
          app.restorePatient(id);
          that.loadPatients();
          that.loadMovedPatients();
          var all = app.getMovedPatients();
          all = all.map(function(p) {
            p.movedOutTime = p.movedOutAt ? formatDate(p.movedOutAt) : '';
            return p;
          });
          that.setData({ movedPatientsFull: all });
          wx.showToast({ title: '已恢复', icon: 'success' });
        }
      }
    });
  },

  noop: function() {}
});

function formatDate(ts) {
  var d = new Date(ts);
  return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' +
    (d.getHours() < 10 ? '0' : '') + d.getHours() + ':' +
    (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
}
